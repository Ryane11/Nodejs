const AnnoncesController = require('./annonces')

module.exports = {
  AnnoncesController
}
